var socket_io = require("socket.io");
// var conversationModel = require("../model/conversation.js");
// var userMolde = require("../model/user");
var io = socket_io();
var socketApi = {};
//ham callback(true) tra ve true ben client
socketApi.io = io;
var nameReceiver = "";
var nameSender = "";
//user la doi tuong chua cac
var nguoiNhan = {};
//var nguoiNhan={}

var user = {};
var uploadListReceiver = function(soc, sender) {
    var socket = soc;
    // var query = conversationModel
    //     .find({ joiner: sender })
    //     .select("joiner")
    //     .populate("joiner");
    // query.exec(function(err, data) {
    //     socket.emit("load list Conversation", { receiverInfo: data });
    // });
    // var query=conversationModel.find({joiner:sender})
    // 							.populate('conversation.sender');
    // query.exec(function(err,data){
    // 	socket.emit('load list Conversation',{receiverInfo:data});

    // })
};

var uploadConversationOld = function(soc, sender, receiver) {
    var socket = soc;
    var query = conversationModel
        .find({ joiner: { $all: [sender, receiver] } })
        .sort("createAt")
        .populate("conversation.sender");
    query.exec(function(err, data) {
        socket.emit("upload conversation old", { conversation: data });
    });
};
var createConversarion = function(idReceiver, idSender, callback) {
    if (user[idSender]) {
        uploadConversationOld(user[idSender], idSender, idReceiver);
        userMolde.findById(idReceiver, function(err, Receiver) {
            user[idSender].emit("create conversation", { otherUser: Receiver });
            uploadConversationOld(user[idSender], idSender, idReceiver);
        });
    }
    if (user[idReceiver]) {
        userMolde.findById(idSender, function(err, sender) {
            //Neu nguoi nhan dang online thi hien cua so chat

            uploadConversationOld(user[idReceiver], idSender, idReceiver);
            user[idReceiver].emit("create conversation", { otherUser: sender });
            uploadConversationOld(user[idReceiver], idSender, idReceiver);
        });
    }
};
io.on("connection", function(socket) {
    socket.nameReceiver = [];

    //dang online
    socket.on("new user", function(data, callback) {
        if (data.idSender == "") {
            callback(false);
        } else {
            if (!(data.idSender in user) || user[data.idSender] != socket) {
                socket.nickname = data.idSender;
                user[socket.nickname] = socket;

                uploadListReceiver(user[socket.nickname], data.idSender);
            }
        }
    });

    socket.on("new chat", function(data, callback) {
        nameReceiver = data.idReceiver;
        nameSender = data.idSender;
        nguoiNhan[nameSender] = data.idReceiver;
        console.log("Xem danh sach nguoiNhan.nameSender", nguoiNhan[nameSender]);

        createConversarion(nameReceiver, nameSender, callback);
    });

    socket.on("get old message", function(data, callback) {
        nameReceiver = data.idReceiver;
        nameSender = data.idSender;

        uploadConversationOld(
            user[socket.nickname],
            data.idSender,
            data.idReceiver
        );
    });

    //
    socket.on("send message", function(data, callback) {
        var receiver = data.receiver;
        var sender = data.sender;
        var joiner = [];
        joiner.push(receiver);
        joiner.push(sender);
        if (data.message.trim() != "") {
            var obj = {
                message: data.message.trim(),
                createAt: Date.now(),
                sender: sender
            };
            conversationModel.find({ joiner: { $all: [sender, receiver] } }, function(
                err,
                data
            ) {
                if (data.length == 0) {
                    var obj2 = new conversationModel({
                        joiner: [sender, receiver],
                        conversation: [obj]
                    });
                    conversationModel.insertMany(obj2, function(err, data) {
                        userMolde.findById(nameSender, function(err, sender) {
                            if (err) throw err;
                            socket.emit("sended", { sender: sender, message: obj });
                            if (user[receiver])
                                user[receiver].emit("new message", {
                                    sender: sender,
                                    message: obj
                                });
                        });
                    });
                } else {
                    conversationModel.findOneAndUpdate({ joiner: { $all: [sender, receiver] } }, { $push: { conversation: obj } }, { safe: true, upsert: true },
                        function(err, conversation) {
                            if (err) throw err;
                            userMolde.findById(nameSender, function(err, sender) {
                                if (err) throw err;
                                socket.emit("sended", { sender: sender, message: obj });
                                if (user[receiver])
                                    user[receiver].emit("new message", {
                                        sender: sender,
                                        message: obj
                                    });
                            });
                        }
                    );
                }
            });
        }
    });

    socket.on("disconnect", function(data) {
        if (!socket.nickname) return;
    });
    0;
});

module.exports = socketApi;