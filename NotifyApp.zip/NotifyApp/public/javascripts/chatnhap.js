$(document).ready(function(){
	var socket = io.connect();
	var chatBtn=$("#chatBtn");
	var idReceiver=$("#idNguoiBan");
	var idSender=$(".id_NguoiDung");

//tham gia vao chat tao 1 nguoi dung tuong ung voi 1 socket
	//
	$('.chatCompent').click(function(){
		$('.nhanvien').hide();
		$(".chat_container").show();
	})
	$('.room').click(function(){
		$('.nhanvien').show();
		$(".chat_container").hide();
	})
	
	socket.emit("new user",{idSender:idSender.val(),idReceiver:idReceiver.val()},function(confirmation){
		//xu ly chua dang nhap
	
	});

	//nhan nut chat
if(chatBtn.length!=0){
	chatBtn[0].addEventListener("click",function(){
			
		if(idSender.val().length!=0){

			if(idReceiver.val()!=idSender.val()){
				//bo het tat ca trang thai active cua cac nguoi dung khac
				//xoa bo danh sach chat cu
				console.log('ko xoa a');
				
				$('.nhanvien').hide();
				$(".chat_container").show();
				var id=idReceiver.val();
			
				var remo=$('#'+id);
			
				remo.remove();
				socket.emit("new chat",{idReceiver:idReceiver.val(),idSender:idSender.val()}, 
				function(confirmation){
				
				});
			}
		
				
		}
		else{
			window.location="/users/login";
		}	
	})

}

	//co doan hoi thoai
	socket.on('create conversation', function(data){
		
		// $('.danhSachNguoiChat ul li.active').each(function(){
		// 	this.removeClass('active');
		// })
		$('.active').removeClass('active');
		var avata="/img/avatar.png";
		var name=data.otherUser.phonenumber;
		if(data.otherUser.avata!="-1"){
			avata=data.otherUser.avata;
		}
		if(data.otherUser.username!=""){
			name=data.otherUser.username;
		}

		var khoi=`
		<li class="active" id="${data.otherUser._id}"> 
		<input type="hidden" name="" class="${data.otherUser._id}" value="${data.otherUser._id}">  
		<span class='Close'>X</span>
		<span class="avatas"><img src="${avata}"></span>
		<div class="nameChat">
		${name}
		</div>
		</li>`;	
		$('.danhSachNguoiChat ul').append(khoi);			
	});

	//xu ly load

	//lay danh sach nhung nguoi da chat trong qua khu
	
	socket.on("load list Conversation",function(data){
	
		
		
		data.receiverInfo.forEach(function(motConversation){
			var person=motConversation.joiner[0];
			var avata="/img/avatar.png";
			if(person._id==idSender.val()){
	
				person=motConversation.joiner[1];
				
			}
			$('.danhSachNguoiChat ul').val("");
			
			console.log(person);
			
			var name=person.phonenumber;
			
			if(person.avata!="-1"){
				avata=person.avata;
			}
			if(person.username!=""){
				name=person.username;
			}
			var khoi=`
		<li id="${person._id}"> 
		<input type="hidden" name="" class="${person._id}" value="${person._id}">  
		<span class='Close'>X</span>
		<span class="avatas"><img src="${avata}"></span>
		<div class="nameChat">
		${name}
		</div>
		</li>`;	
		$('.danhSachNguoiChat ul').append(khoi);		
			
		})
		
		//xuLyLayDoanHoiThoai();
	})
//het looad list
	$('.guiTinNhan')[0].addEventListener("click",function(){
		var active=$('li.active');
		console.log(active);
		
		if(active){
			var message=$('#chatContent').val();
			var idNguoiNhan=$(".danhSachNguoiChat ul li.active input");
			if(!idNguoiNhan){
				alert("Ban chua nhap nguoi chat");
			}
			if(message.trim()==""){
				alert("Ban chua nhap tin nhan");
			}
			else{
				if(!idNguoiNhan.val()){
						
					alert("Ban chua chon nguoi lien lac");
				}
				else if(idSender.val().length==0){
					alert("Ban chua dang nhap");
				}
				else{

					socket.emit("send message",{receiver:idNguoiNhan.val(),message:message.trim(),sender:idSender.val()});
				}
			}
		}else{
			alert("Chọn nguoi can chat")
		}

	})
	//click tnhan
	socket.on("sended",function(data){
		
		socket.emit('get old message',{idReceiver:idReceiver.val(),idSender:idSender.val()}, function(){
			socket.on("upload conversation old",function(data){
				console.log(' load old sended',data);
				
			})
		});

		var date=new Date(data.message.createAt);
                var hour=(date.getHours()>9)?(date.getHours()):("0"+date.getHours());
                var min=(date.getMinutes()>9)?(date.getMinutes()):("0"+date.getMinutes());
                var day=(date.getDate()>9)?(date.getDate()):("0"+date.getDate());
                var mon=(date.getMonth()>9)?(date.getMonth()+1):("0"+(date.getMonth()+1));

                var year=date.getFullYear();
                var ngay=`${hour}:${min} ${day}/${mon}/${year}`;
				var avata="/img/avatar.png";
				var name=data.sender.phonenumber;
				if(data.sender.avata!="-1"){
					avata=data.sender.avata;
				}
				if(data.sender.username!=""){
					name=data.sender.username;
				}
		var khoi=` <li class="you">
					<span class="avatas">
					<img src="${avata}">
					</span>
					<div class="noidungTin">
						<span class="message">${data.message.message}</span>
						<span class="ngayThang">${ngay}</span>
					</div>
			</li>`;
	$('.convertation ul').append(khoi);
	$('#chatContent').val("");

	})
	//sended
	socket.on("new message",function(data){
		

		socket.emit('get old message',{idReceiver:idReceiver.val(),idSender:idSender.val()}, function(){
			socket.on("upload conversation old",function(data){
				console.log('load old new message',data);
				
			})
		});

		var date=new Date(data.message.createAt);
		var hour=(date.getHours()>9)?(date.getHours()):("0"+date.getHours());
		var min=(date.getMinutes()>9)?(date.getMinutes()):("0"+date.getMinutes());
		var day=(date.getDate()>9)?(date.getDate()):("0"+date.getDate());
		var mon=(date.getMonth()>9)?(date.getMonth()+1):("0"+(date.getMonth()+1));

		var year=date.getFullYear();
		var ngay=`${hour}:${min} ${day}/${mon}/${year}`;
		var avata="/img/avatar.png";
		var name=data.sender.phonenumber;
		if(data.sender.avata!="-1"){
			avata=data.sender.avata;
		}
		if(data.sender.username!=""){
			name=data.sender.username;
		}
		
var khoi=` 
	<li class="friend">
			<span class="avatas">
			<img src="${avata}">
			</span>
			<div class="noidungTin">
				<span class="message">${data.message.message}</span>
				<span class="ngayThang">${ngay}</span>
			</div>
	</li>`;
$('.convertation ul').append(khoi);
	})


	var xuLyLayDoanHoiThoai=function(){
		//neu co du lieu
		var chats=document.querySelectorAll('.danhSachNguoiChat ul li');
		
			
		chats.forEach(function(chat){
			chat.addEventListener('click',function(){
			
				$('.active').removeClass('active');
				chat.classList.add('active');
				var x=$('.active');
				console.log(x);
				
				if(x){
					console.log('vao chua');
					
					var idReceiverInfo=$('li.active input');
					console.log(idReceiverInfo.val());
					socket.emit('get old message',{idReceiver:idReceiverInfo.val(),idSender:idSender.val()}, function(){
						socket.on("upload conversation old",function(data){
							console.log(data);
							
						})
					});
				}
			})
		});
		
		}//xu ly nut
	
	socket.on("upload conversation old",function(data){
		console.log(data);
		
		if(data.conversation.length!=0){

		
			var conversation=data.conversation[0].conversation;
			$('.convertation ul').html("");
				conversation.forEach(function(message){
					console.log(message);
					var date=new Date(message.createAt);
						var hour=(date.getHours()>9)?(date.getHours()):("0"+date.getHours());
						var min=(date.getMinutes()>9)?(date.getMinutes()):("0"+date.getMinutes());
						var day=(date.getDate()>9)?(date.getDate()):("0"+date.getDate());
						var mon=(date.getMonth()>9)?(date.getMonth()+1):("0"+(date.getMonth()+1));
			
						var year=date.getFullYear();
						var ngay=`${hour}:${min} ${day}/${mon}/${year}`;
						var avata="/img/avatar.png";
						var name=message.sender.phonenumber;
						if(message.sender.avata!="-1"){
							avata=message.sender.avata;
						}
						if(message.sender.username!=""){
							name=message.sender.username;
						}
				
						var khoi;
				if(message.sender._id==idSender.val()){
		
					 khoi=` <li class="you">
						<span class="avatas">
						<img src="${avata}">
						</span>
						<div class="noidungTin">
							<span class="message">${message.message}</span>
							<span class="ngayThang">${ngay}</span>
						</div>
				</li>`;
				}else{
					khoi=` <li class="friend">
					<span class="avatas">
					<img src="${avata}">
					</span>
					<div class="noidungTin">
						<span class="message">${message.message}</span>
						<span class="ngayThang">${ngay}</span>
					</div>
			</li>`;
		
				}
				$('.convertation ul').append(khoi);
	$('#chatContent').val("");
				})
				
	}})
	
		
	
		setInterval(xuLyLayDoanHoiThoai,500);
});